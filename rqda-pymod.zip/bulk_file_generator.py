#!/usr/bin/env python3
"""
Bulk File Generator for RQDA Web App
Run this script to generate all necessary files at once
"""

import os
from pathlib import Path

def create_directory_structure():
    """Create all required directories"""
    directories = [
        'db', 'core', 'ui', 'ui/components', 'ui/pages', 'ui/utils', 
        'api', 'tests', 'docs', 'deploy', '.github/workflows'
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        
        # Create __init__.py files for Python packages
        if directory in ['db', 'core', 'ui', 'api']:
            (Path(directory) / '__init__.py').write_text(f'"""{directory.title()} package"""\n')

def create_files():
    """Create all application files"""
    
    # Main application file
    Path('app.py').write_text('''# app.py - Main Shiny Application (Phase 1)
import os
import sqlalchemy as sa
from pathlib import Path
from shiny import App, ui, render, reactive
from shiny.types import FileInfo
import pandas as pd
from datetime import datetime

# Import our modules
from db.connection import DatabaseManager
from core.document_manager import DocumentManager

# Initialize database and document manager
db = DatabaseManager()
doc_manager = DocumentManager(db)

# UI Definition
app_ui = ui.page_fluid(
    ui.h1("RQDA Web App - Document Management"),
    
    ui.navset_card_tab(
        ui.nav_panel(
            "Files",
            ui.row(
                ui.column(
                    4,
                    ui.h3("Upload Files"),
                    ui.input_file("file_upload", "Choose text files:", multiple=True, accept=".txt"),
                    ui.br(),
                    ui.input_action_button("upload_btn", "Upload Files", class_="btn-primary"),
                    ui.br(), ui.br(),
                    
                    ui.h3("File List"),
                    ui.output_data_frame("file_list"),
                ),
                ui.column(
                    8,
                    ui.h3("File Viewer"),
                    ui.output_ui("file_viewer"),
                    ui.br(),
                    ui.output_ui("text_selector")
                )
            )
        ),
        ui.nav_panel(
            "About",
            ui.p("RQDA Web App - Phase 1: Core Document Management"),
            ui.p("Upload text files and view their contents with basic text selection.")
        )
    )
)

def server(input, output, session):
    # Reactive values for storing data
    selected_file_id = reactive.Value(None)
    selected_text_info = reactive.Value(None)
    
    @reactive.Effect
    @reactive.event(input.upload_btn)
    def upload_files():
        """Handle file upload"""
        if input.file_upload() is not None:
            files_info = input.file_upload()
            
            for file_info in files_info:
                try:
                    # Read file content
                    content = file_info["datapath"].read_text(encoding='utf-8')
                    
                    # Save to database
                    doc_manager.create_file(
                        name=file_info["name"],
                        content=content
                    )
                    
                    ui.notification_show(f"Successfully uploaded: {file_info['name']}", type="success")
                    
                except Exception as e:
                    ui.notification_show(f"Error uploading {file_info['name']}: {str(e)}", type="error")
    
    @output
    @render.data_frame
    def file_list():
        """Display list of uploaded files"""
        files_df = doc_manager.get_all_files()
        
        # Make it interactive for selection
        return render.DataGrid(
            files_df[['id', 'name', 'date_created', 'size']],
            selection_mode="single"
        )
    
    @reactive.Effect
    def handle_file_selection():
        """Handle file selection from the data grid"""
        selected_rows = file_list.data_view(selected=True)
        if len(selected_rows) > 0:
            file_id = selected_rows.iloc[0]['id']
            selected_file_id.set(file_id)
    
    @output
    @render.ui
    def file_viewer():
        """Display selected file content"""
        if selected_file_id() is None:
            return ui.p("Select a file from the list to view its content.")
        
        file_data = doc_manager.get_file(selected_file_id())
        if file_data is None:
            return ui.p("File not found.")
        
        # Create a text area with the file content that allows text selection
        content_html = file_data['content'].replace('\\n', '<br>')
        
        javascript_code = """
        function getSelectedText() {
            var selectedText = "";
            var startPos = 0;
            var endPos = 0;
            
            if (window.getSelection) {
                var selection = window.getSelection();
                selectedText = selection.toString();
                
                if (selectedText.length > 0) {
                    var range = selection.getRangeAt(0);
                    var preCaretRange = range.cloneRange();
                    var container = document.getElementById('text-content');
                    preCaretRange.selectNodeContents(container);
                    preCaretRange.setEnd(range.startContainer, range.startOffset);
                    startPos = preCaretRange.toString().length;
                    endPos = startPos + selectedText.length;
                    
                    // Send selection info to Shiny
                    Shiny.setInputValue('selected_text', {
                        text: selectedText,
                        start: startPos,
                        end: endPos
                    });
                }
            }
        }
        """
        
        return ui.div(
            ui.h4(f"File: {file_data['name']}"),
            ui.div(
                ui.HTML(f"""
                <div id="text-content" style="
                    border: 1px solid #ddd; 
                    padding: 15px; 
                    max-height: 400px; 
                    overflow-y: auto;
                    background-color: #f9f9f9;
                    font-family: 'Courier New', monospace;
                    line-height: 1.6;
                    cursor: text;
                    user-select: text;
                " onmouseup="getSelectedText()">
                    {content_html}
                </div>
                
                <script>
                {javascript_code}
                </script>
                """)
            )
        )
    
    @output
    @render.ui  
    def text_selector():
        """Display selected text information"""
        if input.selected_text() is not None:
            selection = input.selected_text()
            return ui.div(
                ui.h5("Selected Text:"),
                ui.div(
                    f"Text: '{selection['text']}'",
                    ui.br(),
                    f"Position: {selection['start']} - {selection['end']}",
                    style="background-color: #e8f4fd; padding: 10px; border-left: 4px solid #007bff;"
                )
            )
        return ui.div()

# Create the app
app = App(app_ui, server)
''')

    # Database connection module
    (Path('db') / 'connection.py').write_text('''# db/connection.py - Database Connection Manager
import os
import sqlalchemy as sa
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from contextlib import contextmanager
from dotenv import load_dotenv

load_dotenv()

class DatabaseManager:
    def __init__(self):
        self.engine = None
        self.Session = None
        self._connect()
        
    def _connect(self):
        """Establish database connection"""
        db_host = os.getenv('DB_HOST', 'localhost')
        db_name = os.getenv('DB_NAME', 'rqda_app')
        db_user = os.getenv('DB_USER', 'root')
        db_pass = os.getenv('DB_PASS', '')
        
        connection_string = f"mysql+pymysql://{db_user}:{db_pass}@{db_host}/{db_name}?charset=utf8mb4"
        
        try:
            self.engine = create_engine(connection_string, echo=False)
            self.Session = sessionmaker(bind=self.engine)
            
            # Test connection
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
                
        except Exception as e:
            print(f"Database connection failed: {e}")
            raise
    
    @contextmanager
    def get_session(self):
        """Get database session with automatic cleanup"""
        session = self.Session()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            raise e
        finally:
            session.close()
    
    def execute_query(self, query, params=None):
        """Execute a raw SQL query"""
        with self.engine.connect() as conn:
            result = conn.execute(text(query), params or {})
            return result.fetchall()
    
    def execute_update(self, query, params=None):
        """Execute an update/insert/delete query"""
        with self.engine.connect() as conn:
            result = conn.execute(text(query), params or {})
            conn.commit()
            return result.rowcount
    
    def create_tables(self):
        """Create initial database schema"""
        schema_sql = """
        CREATE TABLE IF NOT EXISTS files (
            id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            content TEXT,
            date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            date_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            owner VARCHAR(100),
            memo TEXT,
            size INT DEFAULT 0,
            INDEX(name),
            INDEX(date_created)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """
        
        with self.engine.connect() as conn:
            conn.execute(text(schema_sql))
            conn.commit()
''')

    # Document manager module  
    (Path('core') / 'document_manager.py').write_text('''# core/document_manager.py - Document Management Core Logic
import pandas as pd
import sqlalchemy as sa
from datetime import datetime
from typing import Optional, List, Dict, Any

class DocumentManager:
    def __init__(self, db_manager):
        self.db = db_manager
        self.db.create_tables()  # Ensure tables exist
    
    def create_file(self, name: str, content: str, owner: str = None, memo: str = None) -> int:
        """Create a new file record in the database"""
        size = len(content.encode('utf-8'))
        
        query = """
        INSERT INTO files (name, content, owner, memo, size) 
        VALUES (:name, :content, :owner, :memo, :size)
        """
        
        params = {
            'name': name,
            'content': content, 
            'owner': owner,
            'memo': memo,
            'size': size
        }
        
        with self.db.engine.connect() as conn:
            result = conn.execute(sa.text(query), params)
            conn.commit()
            return result.lastrowid
    
    def get_file(self, file_id: int) -> Optional[Dict[str, Any]]:
        """Get a single file by ID"""
        query = "SELECT * FROM files WHERE id = :file_id"
        
        with self.db.engine.connect() as conn:
            result = conn.execute(sa.text(query), {'file_id': file_id})
            row = result.fetchone()
            
        if row:
            return {
                'id': row[0],
                'name': row[1], 
                'content': row[2],
                'date_created': row[3],
                'date_modified': row[4],
                'owner': row[5],
                'memo': row[6],
                'size': row[7]
            }
        return None
    
    def get_all_files(self) -> pd.DataFrame:
        """Get all files as a pandas DataFrame"""
        query = """
        SELECT id, name, date_created, size, 
               CASE WHEN memo IS NOT NULL THEN 'Yes' ELSE 'No' END as has_memo
        FROM files 
        ORDER BY date_created DESC
        """
        
        with self.db.engine.connect() as conn:
            result = conn.execute(sa.text(query))
            rows = result.fetchall()
            
        if rows:
            df = pd.DataFrame(rows, columns=['id', 'name', 'date_created', 'size', 'has_memo'])
            # Format size in readable format
            df['size'] = df['size'].apply(self._format_file_size)
            return df
        else:
            return pd.DataFrame(columns=['id', 'name', 'date_created', 'size', 'has_memo'])
    
    def update_file(self, file_id: int, name: str = None, content: str = None, memo: str = None) -> bool:
        """Update file information"""
        updates = []
        params = {'file_id': file_id}
        
        if name is not None:
            updates.append("name = :name")
            params['name'] = name
            
        if content is not None:
            updates.append("content = :content")
            updates.append("size = :size") 
            params['content'] = content
            params['size'] = len(content.encode('utf-8'))
            
        if memo is not None:
            updates.append("memo = :memo")
            params['memo'] = memo
            
        if not updates:
            return False
            
        query = f"UPDATE files SET {', '.join(updates)} WHERE id = :file_id"
        
        with self.db.engine.connect() as conn:
            result = conn.execute(sa.text(query), params)
            conn.commit()
            return result.rowcount > 0
    
    def delete_file(self, file_id: int) -> bool:
        """Delete a file"""
        query = "DELETE FROM files WHERE id = :file_id"
        
        with self.db.engine.connect() as conn:
            result = conn.execute(sa.text(query), {'file_id': file_id})
            conn.commit()
            return result.rowcount > 0
    
    def search_files(self, search_term: str) -> pd.DataFrame:
        """Search files by name or content"""
        query = """
        SELECT id, name, date_created, size
        FROM files 
        WHERE name LIKE :search_term OR content LIKE :search_term
        ORDER BY date_created DESC
        """
        
        params = {'search_term': f'%{search_term}%'}
        
        with self.db.engine.connect() as conn:
            result = conn.execute(sa.text(query), params)
            rows = result.fetchall()
            
        if rows:
            df = pd.DataFrame(rows, columns=['id', 'name', 'date_created', 'size'])
            df['size'] = df['size'].apply(self._format_file_size)
            return df
        else:
            return pd.DataFrame(columns=['id', 'name', 'date_created', 'size'])
    
    @staticmethod
    def _format_file_size(size_bytes: int) -> str:
        """Format file size in human readable format"""
        if size_bytes == 0:
            return "0B"
        
        size_names = ["B", "KB", "MB", "GB"]
        i = 0
        while size_bytes >= 1024 and i < len(size_names) - 1:
            size_bytes /= 1024.0
            i += 1
            
        return f"{size_bytes:.1f}{size_names[i]}"
''')

    # Requirements file
    Path('requirements.txt').write_text('''shiny>=0.6.0
shinyswatch>=0.4.0
sqlalchemy>=2.0.0
pymysql>=1.1.0
pandas>=2.0.0
python-dotenv>=1.0.0
plotly>=5.0.0
python-multipart>=0.0.6
cryptography>=41.0.0
''')

    # Environment template
    Path('.env.example').write_text('''# Database Configuration
DB_HOST=mexico.bbfarm.org
DB_NAME=your_database_name
DB_USER=your_username
DB_PASS=your_password

# Application Configuration
DEBUG=True
SECRET_KEY=your_secret_key_here
''')

    # Gitignore
    Path('.gitignore').write_text('''# Environment variables
.env

# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# Virtual Environment
venv/
env/
ENV/

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Logs
*.log

# Database
*.db
*.sqlite

# Temporary files
*.tmp
*.temp
''')

    # README
    Path('README.md').write_text('''# RQDA Web App

A web-based qualitative data analysis application built with Python Shiny.

## Setup

1. Copy `.env.example` to `.env` and configure database settings
2. Install dependencies: `pip install -r requirements.txt`
3. Run: `shiny run app.py`

## Phase 1 Features

- Upload text files
- View file contents
- Basic text selection
- MySQL database storage

## Next Steps

Move to Phase 2: Basic Coding System
''')

    # GitHub Actions workflow
    (Path('.github/workflows') / 'deploy.yml').write_text('''name: Deploy to Posit Connect

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v4
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.11'
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
        pip install rsconnect-python
    
    - name: Deploy to Posit Connect
      env:
        CONNECT_SERVER: ${{ secrets.CONNECT_SERVER }}
        CONNECT_API_KEY: ${{ secrets.CONNECT_API_KEY }}
      run: |
        rsconnect deploy shiny \\
          --server $CONNECT_SERVER \\
          --api-key $CONNECT_API_KEY \\
          --title "RQDA Web App" \\
          ./app.py
''')

if __name__ == "__main__":
    print("Creating RQDA Web App file structure...")
    create_directory_structure()
    create_files()
    print("✓ All files created successfully!")
    print("\\nNext steps:")
    print("1. Copy .env.example to .env and configure database")
    print("2. Run: pip install -r requirements.txt")
    print("3. Run: shiny run app.py")
    print("4. Push to GitHub when ready")
