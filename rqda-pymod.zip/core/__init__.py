"""Core package"""
